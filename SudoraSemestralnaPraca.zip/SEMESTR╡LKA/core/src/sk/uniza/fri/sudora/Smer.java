
package sk.uniza.fri.sudora;

/**
 *
 * @author Filip
 */
public enum Smer {
    HORE,
    DOLE,
    VPRAVO,
    VLAVO;
}
